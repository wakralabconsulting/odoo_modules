## Module <custom_receipts_for_pos>

#### 05.02.2024
#### Version 17.0.1.0.0
##### ADD
- Initial Commit for POS Receipt Design

#### 17.04.2024
#### Version 17.0.1.0.1
##### BUGFIX
- Fixed the error in printing the receipt

#### 15.06.2024
#### Version 17.0.1.0.2
##### BUGFIX
- Fix the receipt selection for each point of sales

#### 15.06.2024
#### Version 17.0.1.0.3
##### BUGFIX
- Move the configuration to select the receipt from configuration settings to POS configuration


#### 20.08.2024
#### Version 17.0.1.0.4
##### BUGFIX
- Fixed the missing products and amount details in the pos receipts from ticket screen.

#### 05.09.2024
#### Version 17.0.1.0.5
##### BUGFIX
- Fixed the missing company logo in the pos receipts when printing.

#### 27.09.2024
#### Version 17.0.2.0.5
##### BUGFIX
- Fixed the receipt printing order issue.

#### 07.10.2024
#### Version 17.0.3.0.5
##### BUGFIX
- Fixed the receipt printing blank screen.

#### 07.10.2024
#### Version 17.0.3.1.5
##### UPDATE
- Updated the tracking number to custom receipt screen and fixed the issues when tip is enabled. 

#### 27.01.2025
#### Version 17.0.3.1.6
#### BUGFIX

- Fixed the issue of not getting customer data in props.

#### 16.07.2025
#### Version 17.0.3.1.7
#### BUGFIX

- Updated the Unit price and Amount in the custom receipt designs.